<?php
    $lang['welcome'] = 'Bienvenue !';
?>