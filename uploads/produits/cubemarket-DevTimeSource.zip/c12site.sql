-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  jeu. 21 mai 2020 à 20:38
-- Version du serveur :  10.3.22-MariaDB-0+deb10u1
-- Version de PHP :  7.3.14-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `c12site`
--

-- --------------------------------------------------------

--
-- Structure de la table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `config`
--

INSERT INTO `config` (`id`, `name`, `value`) VALUES
(1, 'server_name', 'Cube-Market'),
(2, 'server_infos', 'CubeMarket, le seul est unique marketplace Français fiable !'),
(3, 'site__licence_kilioz', 'WEB-0002-CUBEMARKET-LICENSE');

-- --------------------------------------------------------

--
-- Structure de la table `navigation`
--

CREATE TABLE `navigation` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `type` int(11) NOT NULL,
  `dropdown_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `navigation`
--

INSERT INTO `navigation` (`id`, `name`, `url`, `type`, `dropdown_id`, `date`) VALUES
(1, 'Accueil', 'https://cubemarket.fr/', 0, 0, '2019-12-23 13:42:57'),
(2, 'Produits', 'https://cubemarket.fr/products/', 0, 0, '2019-12-23 13:42:57'),
(8, 'Informations', '#', 1, 0, '2020-02-09 11:10:45'),
(9, 'Conditions générales d\'utilisation', 'https://cubemarket.fr/p/cgu', 2, 8, '2020-02-09 11:11:21'),
(10, 'Conditions générales de vente', 'https://cubemarket.fr/p/cgv', 2, 8, '2020-02-09 11:11:44'),
(13, 'FAQ', 'https://cubemarket.fr/p/faq', 2, 8, '2020-03-30 13:32:38');

-- --------------------------------------------------------

--
-- Structure de la table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `image` text NOT NULL,
  `description` text NOT NULL,
  `user` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `online`
--

CREATE TABLE `online` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `ip` text NOT NULL,
  `expiration` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `online`
--

INSERT INTO `online` (`id`, `user`, `ip`, `expiration`, `date`) VALUES
(2160, 1, '207.46.13.57', '1590078449', '2020-05-21 16:27:29'),
(2161, 1, '40.77.167.146', '1590078558', '2020-05-21 16:29:18');

-- --------------------------------------------------------

--
-- Structure de la table `page`
--

CREATE TABLE `page` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL,
  `last_edit` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `content` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `page`
--

INSERT INTO `page` (`id`, `name`, `url`, `last_edit`, `content`, `date`) VALUES
(1, 'Foire aux questions', 'faq', '2020-03-17 14:32:30', '<blockquote><p>Comment obtenir la clé Paypal pour vendre mes produits sur votre boutique ?</p></blockquote><ul><li>Pour cela, vous devez vous rendre sur <a href=\"https://developer.paypal.com/developer/applications/\">https://developer.paypal.com/developer/applications/</a>.</li><li>Créer une application <b>Live</b>.</li><li>Vous rendre sur l\'application et récupérer le Client ID</li><li>Cela vous permettra de recevoir vos paiements grâce à l\'api Paypal.</li></ul>', '2020-03-17 13:49:59'),
(2, 'CGU', 'cgu', '2020-03-19 20:32:44', '<p>Les présentes Conditions Générales d\'Utilisation ont pour objet de définir les termes et conditions dans lesquelles CubeMarketMC fournit ses Services aux Utilisateurs.<br><br><br>1.&nbsp; DÉFINITIONS<br><br>Services : désigne l\'ensemble des services offerts par CubeMarket par l\'intermédiaire de ses Sites Web (CubeMarket.fr, ...), de ses serveurs de jeux Minecraft et de ses serveurs de communication vocale Discord ...<br><br>Utilisateur : désigne la personne physique, utilisant les services offerts par CubeMarket.<br><br>Données Personnelles : désigne les informations personnelles que l\'Utilisateur a enregistrées lors de son inscription aux Services offerts par CubeMarket et/ou fournis dans le cadre de l\'utilisation des Services.<br><br>Droits de Propriété Intellectuelle : désignent les marques, les noms de domaines, les droits d\'auteur, les copyrights, les dessins, les brevets, les droits sur les bases de données ou tous autres droits de propriété intellectuelle exploités par CubeMarket et nécessaires à ses activités de prestataire de Services.<br><br>Lien Hypertexte : désigne le système de référencement matérialisé par un mot, une icône ou un logo qui permet par un clic de souris de passer d\'un document à un autre sur un même site web ou d\'une page d\'un site web à la page d\'un autre site web.<br><br>Site Web : désigne le site Internet mit à la disposition du public et des Utilisateurs.<br><br>Contenu : désigne l\'ensemble des données (textes, images, audio, vidéos, construction sur les serveurs) publiés par CubeMarket et/ou présentent sur l\'un des Services.<br><br><br>2. ACCEPTATION DES PRÉSENTES CONDITIONS GÉNÉRALES D\'UTILISATION<br>&nbsp;<br>CubeMarket se réserve le droit de modifier sans préavis ou annonce les présentes Conditions Générales d\'Utilisation qui devront être consultées avant tout achat sur les produit L\'Utilisateur doit être majeur ou disposer d\'une autorisation de son responsable avant d\'effectuer un éventuel achat sur la boutique CubeMarket.fr/boutique.<br>Dans le cas où l\'Utilisateur n\'accepte pas les présentes Conditions Générales d\'Utilisation il s\'engage à ne pas utiliser les Services offerts par CubeMarket.<br><br><br>ACCESSIBILITÉ ET CONDITIONS D\'ACCÈS AUX SERVICES<br><br>L\'Utilisateur reconnaît que CubeMarket ne pourra être tenue responsable de tout dommage direct ou indirect survenu à raison de la suppression de l\'accès de l\'Utilisateur aux Services. L\'accès aux Services gratuits est totalement libre.<br><br>3. LIMITATION DE RESPONSABILITÉ<br>&nbsp;<br>&nbsp;L\'Utilisateur reconnaît que :<br>&nbsp;l\'utilisation des Services se fait à ses risques et périls notamment en ce qui concerne le téléchargement de données, de fichiers ou de logiciels qui pourraient endommager son ordinateur ou le support utilisé par l\'Utilisateur. La responsabilité de CubeMarketMC ne peut en particulier être engagée pour toute perte de données, virus, bogues informatiques ou dommages affectant son ordinateur et/ou ses données personnelles et/ou les données de son compte.<br>&nbsp;&nbsp;&nbsp; CubeMarket ne garantit pas l\'adéquation entre les Services proposés et les attentes de l\'Utilisateur ;<br>&nbsp;&nbsp;&nbsp; CubeMarket ne saurait être tenue responsable de la diffusion des données par l\'Utilisateur en violation de droits, notamment privatifs, détenus par des tiers.<br>&nbsp;&nbsp;&nbsp; CubeMarket ne saurait être tenue pour responsable en cas de dommage résultant de causes techniques et notamment de l\'indisponibilité de ses Services et de tout défaut affectant le fonctionnement de ceux-ci.<br>&nbsp;&nbsp;&nbsp; CubeMarket ne pourra être tenue responsable des dommages directs ou indirects tels que pertes financières, manques à gagner, troubles de quelque nature que ce soit qui pourraient résulter de l\'utilisation ou de l\'impossibilité d\'utilisation des Services proposés.<br>&nbsp;&nbsp;&nbsp; CubeMarket ne pourra être tenue pour responsable en cas d\'un déni d\'accès aux divers Services dû à un non-respect des règles et règlements mis en place sur les espaces de partage.<br>&nbsp;&nbsp;&nbsp; <br>4.DONNÉES PERSONNELLES<br>&nbsp;&nbsp;&nbsp; &nbsp;<br>4.1 CONFIDENTIALITÉ DES DONNÉES RECUEILLIES<br><br>En France, les Données Personnelles sont notamment protégées par la loi n° 78-87 du 6 janvier 1978, la loi n° 2004-801 du 6 août 2004, l\'article L. 226-13 du code pénal et la directive Européenne du 24 octobre 1995.<br><br>En tout état de cause CubeMarket ne collecte des Données Personnelles relatives à l\'Utilisateur que pour le besoin de certains Services offerts par CubeMarket. L\'Utilisateur fournit ses informations en toute connaissance de cause, notamment lorsqu\'il procède par lui-même à leur saisie. Il est alors précisé à l\'Utilisateur l\'obligation ou non de fournir ses informations.<br><br>Aucune Donnée Personnelle de l\'Utilisateur de nos Services n\'est publiée à l\'insu de l\'Utilisateur, échangée, transférée, cédée ou vendue sur un support quelconque à des tiers. Seule l\'hypothèse du rachat de CubeMarket et de ses droits permettrait la transmission des dites informations à l\'éventuel acquéreur qui serait à son tour tenu de la même obligation de conservation et de modification des données vis-à-vis de l\'Utilisateur des Services offerts par CubeMarket.<br><br>Les bases de données sont protégées par les dispositions de la loi du 1er juillet 1998 transposant la directive 96/9 du 11 mars 1996 relative à la protection juridique des bases de données.<br><br>4.2&nbsp; UTILISATIONS DES COOKIES<br><br>La navigation sur le Site Web CubeMarket.fr est susceptible de provoquer l\'installation de cookie(s) sur l\'ordinateur de l\'Utilisateur. Un cookie est un fichier de petite taille, qui ne permet pas l\'identification de l\'utilisateur, mais qui enregistre des informations relatives à la navigation d\'un ordinateur sur un site web. Les données ainsi obtenues visent à faciliter la navigation ultérieure sur le Site Web CubeMarket.fr, et ont également vocation à permettre diverses mesures de fréquentation. Le refus d\'installation d\'un cookie peut entraîner l\'impossibilité d\'accéder à certains Services.<br><br>5. OBLIGATIONS DU VENDEUR<br><br>Le Vendeur s\'engage et garantit qu\'il ne proposera dans ses annonces (que cela soit au don, à l\'échange ou à la vente) que des produits et services dont il est propriétaire ou sur lesquels il dispose des droits lui permettant de les proposer. Le Vendeur s\'interdit à ce titre notamment de proposer tout produit consistant en des œuvres contrefaisantes au sens du Code la propriété intellectuelle ou tout produit ou service dont la commercialisation est réglementée en <br>vertu de dispositions législatives, réglementaires ou contractuelles<br><br>6.&nbsp; L\'UTILISATEUR<br><br>L\'Utilisateur inscrit au Site (membre) a la possibilité d\'y accéder en se connectant grâce à ses identifiants (adresse e-mail définie lors de son inscription et mot de passe). L\'utilisateur est responsable de tout ce qu\'il fait sur le compte en question.<br><br>7. PUBLICATIONS DE RESSOURCES<br><br>Nous ne somme pas responsable des ressources publiées par les vendeurs.<br>Nous vérifions tout les produits proposés pour limité l\'arnaque sur notre site.<br></p>', '2020-03-17 14:32:46'),
(3, 'CGV', 'cgv', '2020-03-22 11:00:44', '<p>1. DÉFINITIONS<br><br>Services : désigne l\'ensemble des services offerts par CubeMarket par l\'intermédiaire de ses sites web (CubeMarket.fr, ...), de ses serveurs de jeux Minecraft et de ses serveurs de communication vocale Discord...).<br><br>Utilisateur : désigne la personne physique, utilisant les Services offerts par CubeMarket.<br><br>2. OBJET<br><br>Les présentes Conditions Générales de Vente ont pour objet de définir les termes et conditions dans lesquelles CubeMarket vend et livre des produits (biens immatériels) aux Utilisateurs. Tout achat d\'un produit sur l\'un de nos Services se fera dans le respect des présentes Conditions Générales de Vente.<br><br>3. ACCEPTATION DES PRÉSENTES CONDITIONS GÉNÉRALES DE VENTE<br><br>L\'Utilisateur, déclare avoir pris connaissance et avoir accepté expressément et de manière inconditionnelle les présentes Conditions Générales de Vente en vigueur au jour de l\'accès à la boutique CubeMarket.fr/boutique et à la souscription aux Services offerts par CubeMarket.<br><br>CubeMarket se réserve le droit de modifier tout ou partie et à tout moment les présentes Conditions Générales de Vente. Il appartient en conséquence à l\'Utilisateur de se référer régulièrement à la dernière version des Conditions Générales de Vente disponible en permanence sur la boutique CubeMarket.fr/boutique Tout usage des Services après modification des Conditions Générales de Vente, vaut acceptation pure et simple par l\'Utilisateur des nouvelles Conditions Générales de Vente.<br><br>Un non-respect des Conditions Générales Vente pourra conduire à des poursuites et une interdiction d\'utilisation des Services offerts par CubeMarket. Une interdiction d\'utilisation ou d\'accès aux Services offerts par CubeMarket ne donne pas au client le droit à un remboursement. Le client est tenu de respecter le règlement de nos Services et les règles de savoir-vivre.<br><br>4. PAIEMENT<br><br>Le paiement s\'effectue en ligne par le biais des services Paypal, Paysafecard et Sms.<br><br>Les informations personnelles ainsi que les numéros de carte bancaire ne passent jamais en clair entre le navigateur et le serveur, les données sont signées et cryptées et transmises par le protocole SSL.<br><br>5. MODALITÉS DE LIVRAISON<br><br>Vous n\'avez aucuns frais d\'expédition supplémentaires à payer puisque le produit est un bien immatériel.<br><br>Nous vous livrerons les produits pour le pseudo indiqué dans le formulaire de commande. La livraison est effectuée lorsque le service de paiement nous indique que votre paiement a été validé. Cette durée est inférieure à 10 minutes avec Paypal, Paysafecard et SMS.<br><br>6. DROIT APPLICABLE<br><br>Les présentes conditions sont soumises à la loi française.<br><br>En cas de litige sur le fond ou sur la forme, les tribunaux français seront seuls compétents.<br><br>7. MODALITÉS DE REMBOURSEMENT<br><br>CubeMarket livre des produits immatériels, aucun remboursement ou échange n\'est possible après que le produit ait été livré.<br><br><br></p>', '2020-03-17 14:32:54'),
(4, 'A Propos', 'about', '2020-03-19 20:35:40', '', '2020-03-19 20:35:40'),
(5, 'Mentions légales', 'mentions', '2020-03-28 19:58:45', '<p>En vertu de l\'article 6 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l\'économie\r\nnumérique, il est précisé aux utilisateurs du site internet https://cubemarket.fr/ l\'identité des différents\r\nintervenants dans le cadre de sa réalisation et de son suivi:<br><br><b><u>Propriétaire </u></b>: David C.<br><b><u>Responsable publication</u></b> : CubeMarket – contact@cubemarket.fr&nbsp;<br>Le responsable publication est une personne physique ou une personne morale.\r\n<br><u><b>Webmaster </b></u>: contact@cubemarket.fr<br><u><b>Hébergeur </b></u>: Contabo – https://contabo.com/ 81549 Munich Aschauer Straße 32a\r\n<br><u><b>Délégué à la protection des données</b></u> : CubeMarket – contact@cubemarket.fr<br></p>', '2020-03-19 20:35:51');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__category`
--

CREATE TABLE `paiement__category` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `country` int(11) NOT NULL,
  `devise` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__category`
--

INSERT INTO `paiement__category` (`id`, `name`, `country`, `devise`) VALUES
(1, 'Carte Bancaire', 5, '€'),
(2, 'Audiotel', 1, '€'),
(3, 'SMS', 1, ' €'),
(4, 'Neosurf', 5, '€'),
(5, 'Paypal', 5, '€'),
(7, 'Audiotel', 2, '€'),
(8, 'SMS', 2, '€'),
(12, 'Audiotel', 3, '$ CAD'),
(17, 'Audiotel', 4, 'CH'),
(18, 'SMS', 4, 'CH'),
(21, 'Paysafecard', 5, '€');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__country`
--

CREATE TABLE `paiement__country` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__country`
--

INSERT INTO `paiement__country` (`id`, `name`) VALUES
(1, 'France'),
(2, 'Belgique'),
(3, 'Canada'),
(4, 'Suisse'),
(5, 'International');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__list`
--

CREATE TABLE `paiement__list` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `price` text NOT NULL,
  `reception` text NOT NULL,
  `code` text NOT NULL,
  `link_api` enum('true','false') NOT NULL,
  `url__api` text NOT NULL,
  `country` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__list`
--

INSERT INTO `paiement__list` (`id`, `category`, `price`, `reception`, `code`, `link_api`, `url__api`, `country`, `date`) VALUES
(1, 1, '5', '3.40', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-500', 5, '2020-03-07 13:19:15'),
(2, 1, '10', '6.77', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-1000', 5, '2020-03-07 13:23:10'),
(3, 1, '15', '10.17', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-1500', 5, '2020-03-07 13:23:10'),
(4, 1, '20', '13.85', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-2000', 5, '2020-03-07 13:23:10'),
(5, 1, '25', '17.20', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-2500', 5, '2020-03-07 13:23:10'),
(6, 1, '30', '20.55', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-3000', 5, '2020-03-07 13:23:10'),
(7, 1, '35', '24.10', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-3500', 5, '2020-03-07 13:23:10'),
(8, 1, '40', '27.45', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-4000', 5, '2020-03-07 13:23:10'),
(9, 1, '45', '30.85', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-4500', 5, '2020-03-07 13:23:10'),
(10, 1, '50', '34.25', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-5000', 5, '2020-03-07 13:23:10'),
(11, 1, '60', '41.20', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-6000', 5, '2020-03-07 13:23:10'),
(12, 1, '70', '47.95', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-7000', 5, '2020-03-07 13:23:10'),
(13, 1, '80', '54.80', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-8000', 5, '2020-03-07 13:23:10'),
(14, 1, '90', '63', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-9000', 5, '2020-03-07 13:23:10'),
(15, 1, '100', '70', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/creditCard?rate=MO-CREDITCARD-10000', 5, '2020-03-07 13:23:10'),
(16, 2, '1.99', '1.05', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 899 171 825 Service 1.99 euros par appel + prix d\'un appel', 'false', '', 1, '2020-03-07 13:30:37'),
(17, 2, '3', '1.50', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 240 Service 3 euros par appel + prix d\'un appel', 'false', '', 1, '2020-03-07 13:30:37'),
(18, 2, '6', '3', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 246 Service 3 euros par appel + prix d\'un appel (2 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(19, 2, '9', '4.5', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 251 Service 3 euros par appel + prix d\'un appel (3 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(20, 2, '6', '12', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 254 Service 3 euros par appel + prix d\'un appel (4 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(21, 2, '15', '7.50', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 258 Service 3 euros par appel + prix d\'un appel (5 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(22, 2, '18', '9', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 262 Service 3 euros par appel + prix d\'un appel (6 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(23, 2, '21', '10.50', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le 0 897 041 267 Service 3 euros par appel + prix d\'un appel (7 appels)', 'false', '', 1, '2020-03-07 13:30:37'),
(24, 3, '3', '1.35', 'CODE au 8 22 02  3 euros par SMS + prix du SMS 1 envoi de SMS par code d\'accès', 'false', '', 1, '2020-03-07 13:30:37'),
(25, 4, '3', '2.03', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-300', 5, '2020-03-07 13:30:37'),
(26, 4, '5', '3.38', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-500', 5, '2020-03-07 13:30:37'),
(27, 4, '10', '6.75', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-1000', 5, '2020-03-07 13:30:37'),
(28, 4, '15', '10.13', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-1500', 5, '2020-03-07 13:30:37'),
(29, 4, '20', '13.5', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-2000', 5, '2020-03-07 13:30:37'),
(30, 4, '25', '16.88', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-2500', 5, '2020-03-07 13:30:37'),
(31, 4, '30', '20.25', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-3000', 5, '2020-03-07 13:30:37'),
(32, 4, '50', '33.75', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-5000', 5, '2020-03-07 13:30:37'),
(33, 4, '100', '67.5', '', 'true', 'https://api.dedipass.com/v1/index.php/pay/Neosurf?rate=NEOSURF-10000', 5, '2020-03-07 13:30:37'),
(34, 7, '2', '0.85', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le\r\n090533770\r\n2 €/appel - L\'appel dure environ 1mn.\r\n€ 2/appel- het gesprek duurt ca. 1 min.\r\n<b>Service interdit aux moins de 12 ans</b>', 'false', '', 2, '2020-03-07 13:30:37'),
(35, 8, '3', '1.05', 'Pour payer par SMS, obtenez un code d\'accès en envoyant par SMS\r\nPASS au\r\n7202\r\n3 EUR / ACHAT', 'false', '', 2, '2020-03-07 13:30:37'),
(36, 17, '10', '5', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le\r\n0906 666 914\r\nFr. 10/appel depuis une ligne fixe.\r\nCode obtained in about 1mn15', 'false', '', 4, '2020-03-07 13:30:37'),
(37, 18, '10', '2.90', 'Pour payer par SMS, obtenez un code d\'accès en envoyant par SMS\r\nTAP BILL au 565\r\n10 CHF/SMS\r\n1 SMS par code d\'accès.\r\n1 SMS pro Zungangscode.\r\n1 solo invio di SMS per codice di accesso.', 'false', '', 4, '2020-03-07 13:30:37'),
(38, 12, '7', '2.50', 'Pour payer par téléphone, obtenez un code d\'accès en appellant le\r\n19007898787\r\n#0007 depuis un portable Bell Mobilité - from a Bell Mobility cellular\r\n$7 CAD/appel - $7 CAD/call\r\nDepuis un poste fixe - From a land line\r\nVous devez être agé de plus de 18 ans pour utiliser ce service.\r\nYou must be 18 or over to access serv', 'false', '', 3, '2020-03-07 13:30:37'),
(40, 5, '5', '4.58', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-500', 5, '2020-03-07 13:30:37'),
(41, 5, '10', '9.41', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-1000', 5, '2020-03-07 13:30:37'),
(42, 5, '20', '19.07', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-2000', 5, '2020-03-07 13:30:37'),
(43, 5, '30', '28.73', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-3000', 5, '2020-03-07 13:30:37'),
(44, 5, '40', '38.39', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-4000', 5, '2020-03-07 13:30:37'),
(45, 5, '50', '48.05', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-5000', 5, '2020-03-07 13:30:37'),
(46, 5, '60', '57.71', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-6000', 5, '2020-03-07 13:30:37'),
(47, 5, '70', '67.37', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-7000', 5, '2020-03-07 13:30:37'),
(48, 5, '80', '77.03', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-8000', 5, '2020-03-07 13:30:37'),
(49, 5, '90', '86.69', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-9000', 5, '2020-03-07 13:30:37'),
(50, 5, '100', '96.35', '', 'true', 'https://api.dedipass.com/v1/paypal?key=77ee63194e039db13caa9783c852e207&rate=PAYPAL-10000', 5, '2020-03-07 13:30:37');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__mobile`
--

CREATE TABLE `paiement__mobile` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `price` text NOT NULL,
  `code` text NOT NULL,
  `rate` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__mobile`
--

INSERT INTO `paiement__mobile` (`id`, `user`, `price`, `code`, `rate`, `date`) VALUES
(1, 1, '1', 'KILIOZ62', 'TEST-CODE', '2020-03-17 15:22:21');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__paypal`
--

CREATE TABLE `paiement__paypal` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `paymentID` text NOT NULL,
  `payerID` text NOT NULL,
  `token` text NOT NULL,
  `price` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__paypal`
--

INSERT INTO `paiement__paypal` (`id`, `user`, `product_id`, `paymentID`, `payerID`, `token`, `price`, `date`) VALUES
(2, 1, 1, 'PAYID-LZ2TD4Q1N721422NK502803X', 'Y6RTL4YHV2E3W', 'EC-8U0237886Y4006839', '6', '2020-03-20 21:14:07');

-- --------------------------------------------------------

--
-- Structure de la table `paiement__transfert`
--

CREATE TABLE `paiement__transfert` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `solde` varchar(255) NOT NULL,
  `paypal` text NOT NULL,
  `etat` enum('inwork','cancel','accepted') NOT NULL,
  `paypal_id` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `edit` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `paiement__transfert`
--

INSERT INTO `paiement__transfert` (`id`, `user`, `solde`, `paypal`, `etat`, `paypal_id`, `date`, `edit`) VALUES
(1, 1, '59.99', 'mateo.mrozek.pro@gmail.com', 'cancel', '', '2020-03-19 16:58:11', '2020-03-19 17:16:04'),
(2, 1, '40.01', 'mateo.mrozek.pro@gmail.com', 'accepted', 'PAY-00001', '2020-03-19 17:05:53', '2020-03-19 17:16:32');

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `id_grade` int(11) NOT NULL,
  `nom` text NOT NULL,
  `beta_access` int(11) NOT NULL DEFAULT 1,
  `is_admin` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `quota__limit` int(11) NOT NULL,
  `PERM__ADM_EDIT_USER` int(11) NOT NULL,
  `PERM__ADM_EDIT__PRODUCT` int(11) NOT NULL,
  `PERM__ADM_ADD_NEWS` int(11) NOT NULL,
  `PERM__ADM_CONFIGURATION_SITE` int(11) NOT NULL,
  `PERM__ADM_EDIT_EMAIL` int(11) NOT NULL,
  `PERM__ADM_EDIT_MONEY` int(11) NOT NULL,
  `PERM__ADM_EDIT_PWD` int(11) NOT NULL,
  `PERM__ADM_EDIT_RANK` int(11) NOT NULL,
  `PERM__ADM_PAGE` int(11) NOT NULL,
  `PERM__ADM_EDIT_PAGE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `id_grade`, `nom`, `beta_access`, `is_admin`, `date`, `quota__limit`, `PERM__ADM_EDIT_USER`, `PERM__ADM_EDIT__PRODUCT`, `PERM__ADM_ADD_NEWS`, `PERM__ADM_CONFIGURATION_SITE`, `PERM__ADM_EDIT_EMAIL`, `PERM__ADM_EDIT_MONEY`, `PERM__ADM_EDIT_PWD`, `PERM__ADM_EDIT_RANK`, `PERM__ADM_PAGE`, `PERM__ADM_EDIT_PAGE`) VALUES
(1, 0, 'Client', 1, 0, '2020-02-28 16:18:25', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 1, 'Admin', 1, 1, '2020-03-16 17:48:55', 9999, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(3, 2, 'Banni', 0, 0, '2020-03-19 15:50:51', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 3, 'Vendeur Premium', 1, 0, '2020-03-20 16:01:37', 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 4, 'Développeur', 1, 1, '2020-03-21 02:15:38', 9999, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `products__category`
--

CREATE TABLE `products__category` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products__category`
--

INSERT INTO `products__category` (`id`, `name`, `url`) VALUES
(1, 'Serveurs', 'serveurs'),
(2, 'Maps', 'maps'),
(4, 'Site Internet', 'sites'),
(5, 'Skript', 'skript'),
(6, 'Logo', 'logo'),
(7, 'Autre', 'autre');

-- --------------------------------------------------------

--
-- Structure de la table `products__list`
--

CREATE TABLE `products__list` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `title` text NOT NULL,
  `url` text NOT NULL,
  `description` text NOT NULL,
  `file` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `edit` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `etat` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products__list`
--

INSERT INTO `products__list` (`id`, `user`, `category`, `title`, `url`, `description`, `file`, `price`, `date`, `edit`, `etat`, `image`) VALUES
(2, 2, 5, 'Skript de sanction', 'Skript-de-sanction-2', '<h2>Skript Sanction</h2>\r\n\r\n<p>Ce skript contient plusieurs catégories:<br>\r\n\r\n- Assistant : Mute, Kick<br>\r\n\r\n- Modération : Mute, Kick, Tempban<br>\r\n\r\n-Administrateur : Mute, Kick , tempban , ban, ban-ip<br>\r\n\r\nCommande : /sanction <br>\r\n\r\nPermission :<br>\r\n- Menu : sanction.server<br>\r\n\r\n- Assistant : assistant.mod<br>\r\n\r\n-Modérateur : moderation.mod<br>\r\n\r\nAdministeur : admin.mod<br>\r\n\r\n\r\nVoici les screens en questions.\r\n</p>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277086904320040/modo.PNG\"><br><br><br>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277102175780884/modo2.PNG\"><br><br><br>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277107800211456/admin.PNG\"><br><br><br>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277108664107128/sanction_assistant.PNG\"><br><br><br>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277113026445424/assistant.PNG\"><br><br><br>\r\n<img src=\"https://cdn.discordapp.com/attachments/653672049826463744/690277116561981511/menu.PNG\"><br><br><br>\r\n<p></p>', 'Skript_Sanction.zip', '3', '2020-03-19 18:02:47', '2020-03-30 13:07:00', 1, 'menu.PNG'),
(3, 6, 5, 'Maintenance Skript', 'Maintenance-Skript-3', '<p>/maintenance : Ouvre un menu pour activer la maintenance ou desactiver</p><p>/maintenancejoininfo : Savoir des que un joueur join pendant la maintenance</p><p>/bypassmaintenance : Ajouter un joueur a la Maintenance Bypass<br></p><p><br></p><p><br></p>', 'maintenance_(1).zip', '0', '2020-03-29 18:49:16', '2020-03-30 09:32:12', 1, ''),
(4, 2, 1, 'Pack Bungeecord', 'Pack-Bungeecord-4', '<p>Pack Bungeecord contient un lobby est un bungeecord sécurisé est retravailler.<br>Le spawn à été crée par une team de buildeur pour mon serveur<br></p>', 'Pack_Bungeecord.zip', '5', '2020-04-09 18:03:44', '2020-04-11 09:23:21', 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `products__payements`
--

CREATE TABLE `products__payements` (
  `id` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `price` text NOT NULL,
  `type` enum('PAYEMENT','DOWNLOAD__UPDATE') NOT NULL,
  `product__version` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products__payements`
--

INSERT INTO `products__payements` (`id`, `id_product`, `user`, `price`, `type`, `product__version`, `date`) VALUES
(1, 1, 1, '6', 'PAYEMENT', '1.0.0', '2020-03-15 20:50:17'),
(2, 1, 1, '6', 'PAYEMENT', '1.0.0', '2020-03-20 21:14:07'),
(3, 1, 1, '6', 'DOWNLOAD__UPDATE', '1.0.0', '2020-03-29 19:09:07'),
(4, 1, 1, '6', 'DOWNLOAD__UPDATE', '1.0.0', '2020-03-29 19:57:29'),
(5, 1, 1, '6', 'DOWNLOAD__UPDATE', '1.0.0', '2020-03-29 19:57:47'),
(7, 3, 6, '0', 'PAYEMENT', 'V1', '2020-03-30 11:19:46'),
(8, 3, 4, '0', 'PAYEMENT', 'V1', '2020-03-31 02:01:30'),
(9, 3, 12, '0', 'PAYEMENT', 'V1', '2020-04-06 16:02:16'),
(10, 3, 15, '0', 'PAYEMENT', 'V1', '2020-04-14 15:38:09'),
(11, 3, 18, '0', 'PAYEMENT', 'V1', '2020-04-28 17:55:06');

-- --------------------------------------------------------

--
-- Structure de la table `products__updates`
--

CREATE TABLE `products__updates` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `file` text NOT NULL,
  `version__name` text NOT NULL,
  `version__id` text NOT NULL,
  `version__updated` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products__updates`
--

INSERT INTO `products__updates` (`id`, `user`, `id_product`, `file`, `version__name`, `version__id`, `version__updated`, `date`) VALUES
(2, 6, 3, 'maintenance_(1)1.zip', 'V1', 'V1', '', '2020-03-29 18:52:12');

-- --------------------------------------------------------

--
-- Structure de la table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `button_text1` text NOT NULL,
  `button_url1` text NOT NULL,
  `button_text2` text NOT NULL,
  `button_url2` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `slider`
--

INSERT INTO `slider` (`id`, `image`, `title`, `description`, `button_text1`, `button_url1`, `button_text2`, `button_url2`, `date`) VALUES
(1, 'https://i.devkilioz.eu/Photoshop_daDFuK3T0d.png', 'Bienvenue !', 'Bienvenue sur CubeMarket ! Le seul est unique site Français fiable pour vos ventes/achats sur le jeu Minecraft', 'S\'inscrire', 'https://cubemarket.fr/inscription', '', '', '2020-03-06 11:02:07'),
(2, 'https://i.devkilioz.eu/Photoshop_daDFuK3T0d.png', 'Disponible dès le 21 Mars 2020 !', 'L\'ouverture de la plateforme aura lieu le 21 Mars 2020 !', '', '', '', '', '2020-03-06 11:02:07');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `pseudo` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `ip` text NOT NULL,
  `url` text NOT NULL,
  `argent` varchar(255) NOT NULL DEFAULT '0.00',
  `grade` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` text NOT NULL,
  `paypal__client` text NOT NULL,
  `paypal__secret` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `pseudo`, `email`, `password`, `ip`, `url`, `argent`, `grade`, `date`, `last_login`, `paypal__client`, `paypal__secret`) VALUES
(1, 'KilioZ', 'mateo@dev-time.eu', 'af5a8d9b75cb1eb569d2f0addfaf671984488d40', '176.176.87.16', 'kilioz', '0', 4, '2020-02-28 16:21:42', '2020-05-21 15:54:03', 'Aa3LzYfkyFSMl2DPBvXc1ZvIo-S7omwGljBK1H5R8ocROCbb4aDTuD49KoU4jrP2mhJx8mFYCc5Z3bmb', 'EFvfTWFgzmqQdoqZE46D9ta9qMxFYgcr-AK-Lm6tx34SrTfABM31lwzUQOn3qkw3GvGri_8UCB0AQwnp'),
(2, 'DavidCbl', 'venisiumnetwork@gmail.com', '6c0efd72f30af6326610b70ce691f592acbafc1e', '84.98.235.37', 'davidcbl', '0.00', 1, '2020-03-09 17:13:05', '2020-05-19 21:17:25', 'AXfXQiQVuXY8ZbhDMOJiz3-md_Mw1hir40N2isTm0hQk3WNWOFtSzvFxKVtxVvIje7q6lZDKcJPczOQB', 'EO3QnD9ZEjIbNL0kHtasSZKlThuS2AZ6bJqDHI9dBm7lbYOPdDws_Anjd68zrHGOucGcgGNShn3NgfCW'),
(3, 'AyKo', 'kowle282005@gmail.com', '093f4f25c71fa37b1f8891048e4bd7efd6996a83', '41.96.20.119', 'ayko', '0.00', 0, '2020-03-20 15:57:49', '2020-03-27 11:22:15', '', ''),
(4, 'Thomasmrqz.fr', 'thomas@famille-marquez.fr', '03cd538a7a3cc427df71f74781447a61a37171eb', '77.201.158.115', 'thomasmrqzfr', '0.00', 0, '2020-03-27 11:49:58', '2020-03-31 04:01:05', '', ''),
(5, 'gaetanptx', 'contact@gaetanptx.com', 'fbc0e1ccd913727d9c4930f46864be53e03dcbdd', '37.170.28.123', 'gaetanptx', '0.00', 0, '2020-03-29 11:27:07', '2020-03-29 13:27:42', '', ''),
(6, '_k0as', 'k0asthebest@gmail.com', 'dcbc4b36110891ee769ea170c3d6fdc96f11d242', '176.132.12.251', '_k0as', '0.00', 0, '2020-03-29 18:29:49', '2020-03-30 11:30:14', '', ''),
(7, 'Hakeim121', 'kyerranesther@gmail.com', 'dc899aae11a6712b9f721bee50175afaf1667b41', '80.12.254.168', 'hakeim121', '0.00', 0, '2020-03-29 19:28:44', '', '', ''),
(8, 'Ayko', 'paypal282005@gmail.com', 'cc1b71ad1af2566fedf87ae8fb30f9e3de59e8dd', '41.96.149.26', 'ayko', '0.00', 0, '2020-03-30 13:23:49', '2020-04-08 01:52:47', '', ''),
(9, 'HelloW0rld', 'HelloW0rld@yopmail.com', '44ea24de2e686ccadec6efce7db4c76782fb4275', '171.25.193.77', 'hellow0rld', '0.00', 0, '2020-03-31 18:55:19', '2020-03-31 20:55:58', '', ''),
(10, 'alert', 'aaaaaaaa@yopmail.com', 'b480c074d6b75947c02681f31c90c668c46bf6b8', '94.230.208.148', 'alertxss', '0.00', 0, '2020-03-31 19:04:44', '', '', ''),
(11, 'MathSurYoutube', 'themonsterjump@gmail.com', '114ad79ba26afa83f0de56c310d6db3fe44fc525', '37.167.174.42', 'mathsuryoutube', '0.00', 0, '2020-04-04 12:28:54', '2020-04-04 14:29:26', '', ''),
(12, 'Theoo_', 'theosarrat@gmail.com', '11d314ce609a4d49c87f88120f4cbef36433eab2', '109.23.55.228', 'theoo_', '0.00', 0, '2020-04-06 16:01:41', '2020-04-06 18:02:02', '', ''),
(13, 'Captain34', 'terraforia@gmail.com', '35cc96f3738556e2429689309d6386b0dd8c2761', '213.49.15.214', 'captain34', '0.00', 0, '2020-04-10 18:45:10', '2020-04-10 20:45:20', '', ''),
(14, 'greshyme', 'greshyme@gmail.com', 'a409ef3d32498c3667a31fdc0ad90b17d44deed5', '176.163.56.229', 'greshyme', '0.00', 2, '2020-04-12 18:49:07', '2020-04-12 20:49:15', '', ''),
(15, 'StarWeizz', 'antonin.riviere40@gmail.com', '78dd86a0b51aa64bcfcbc9e0c862fb083539ff1b', '92.136.112.52', 'starweizz', '0.00', 0, '2020-04-14 15:33:29', '2020-04-14 17:33:45', '', ''),
(16, 'Soway', 'slydixsuryt@gmail.com', '66cd8cd1a05ccf9446f4476ed03938e1fd971f45', '90.54.106.153', 'soway', '0.00', 0, '2020-04-19 18:47:59', '2020-04-19 20:48:19', '', ''),
(17, 'GreatSoulReaper', 'Raphou.DJ@outlook.fr', 'e73585aa1cfbd0c2a8769e353e8beacc237c2d62', '176.136.160.129', 'greatsoulreaper', '0.00', 0, '2020-04-27 05:12:28', '2020-04-27 07:12:50', '', ''),
(18, 'NicolasDev', 'boutiquegamer53@gmail.com', '7f7a2d8e3ac7f9839df34d057c936891361f00ec', '77.203.29.88', 'nicolasdev', '0.00', 0, '2020-04-28 17:54:33', '2020-04-28 19:54:44', '', ''),
(19, 'Test', 'MrSweeb@outlook.fr', '8a2da05455775e8987cbfac5a0ca54f3f728e274', '109.89.138.36', 'test', '0.00', 0, '2020-04-30 02:05:49', '2020-04-30 04:06:21', '', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `navigation`
--
ALTER TABLE `navigation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__category`
--
ALTER TABLE `paiement__category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__country`
--
ALTER TABLE `paiement__country`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__list`
--
ALTER TABLE `paiement__list`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__mobile`
--
ALTER TABLE `paiement__mobile`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__paypal`
--
ALTER TABLE `paiement__paypal`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paiement__transfert`
--
ALTER TABLE `paiement__transfert`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products__category`
--
ALTER TABLE `products__category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products__list`
--
ALTER TABLE `products__list`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products__payements`
--
ALTER TABLE `products__payements`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products__updates`
--
ALTER TABLE `products__updates`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `navigation`
--
ALTER TABLE `navigation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `online`
--
ALTER TABLE `online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2162;

--
-- AUTO_INCREMENT pour la table `page`
--
ALTER TABLE `page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `paiement__category`
--
ALTER TABLE `paiement__category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `paiement__country`
--
ALTER TABLE `paiement__country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `paiement__list`
--
ALTER TABLE `paiement__list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT pour la table `paiement__mobile`
--
ALTER TABLE `paiement__mobile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `paiement__paypal`
--
ALTER TABLE `paiement__paypal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `paiement__transfert`
--
ALTER TABLE `paiement__transfert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `products__category`
--
ALTER TABLE `products__category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `products__list`
--
ALTER TABLE `products__list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `products__payements`
--
ALTER TABLE `products__payements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `products__updates`
--
ALTER TABLE `products__updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
